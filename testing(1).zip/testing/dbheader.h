﻿#ifndef DBHEADER_H
#define DBHEADER_H

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

#endif // DBHEADER_H
